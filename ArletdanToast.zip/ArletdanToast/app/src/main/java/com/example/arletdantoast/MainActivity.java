package com.example.arletdantoast;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button btnTampilkan;
    private static final String CHANNEL_ID = "notif_channel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        btnTampilkan = findViewById(R.id.btnTampilkan);

        // Membuat Notifikasi Channel (Wajib untuk Android 8+)
        createNotificationChannel();

        btnTampilkan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tampilkanAlertDialog();
            }
        });
    }

    private void tampilkanAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Konfirmasi");
        builder.setMessage("Apakah akan menampilkan notifikasi?");

        builder.setPositiveButton("Ya", (dialog, which) -> {
            String teks = editText.getText().toString();
            if (!teks.isEmpty()) {
                // Menampilkan Toast
                Toast.makeText(MainActivity.this, teks, Toast.LENGTH_SHORT).show();

                // Menampilkan Notifikasi
                tampilkanNotifikasi("Notifikasi Baru", teks);
            } else {
                Toast.makeText(MainActivity.this, "Teks kosong!", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Tidak", (dialog, which) -> dialog.dismiss());

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Channel Notifikasi";
            String description = "Channel untuk menampilkan notifikasi";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void tampilkanNotifikasi(String judul, String isi) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground) // Gunakan ikon yang ada di proyek
                .setContentTitle(judul)
                .setContentText(isi)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }
        notificationManager.notify(1, builder.build());
    }
}