package com.example.pembuatanactivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText websiteEditText, locationEditText, shareTextEditText;
    Button openWebsiteButton, openLocationButton, shareTextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        websiteEditText = findViewById(R.id.website_edittext);
        locationEditText = findViewById(R.id.location_edittext);
        shareTextEditText = findViewById(R.id.share_text_edittext);

        openWebsiteButton = findViewById(R.id.open_website_button);
        openLocationButton = findViewById(R.id.open_location_button);
        shareTextButton = findViewById(R.id.share_text_button);

        openWebsiteButton.setOnClickListener(v -> openWebsite());
        openLocationButton.setOnClickListener(v -> openLocation());
        shareTextButton.setOnClickListener(v -> shareText());
    }

    private void openWebsite() {
        String url = websiteEditText.getText().toString();
        Uri webpage = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "No application can handle this request", Toast.LENGTH_SHORT).show();
        }
    }

    private void openLocation() {
        String location = locationEditText.getText().toString();
        Uri addressUri = Uri.parse("geo:0,0?q=" + Uri.encode(location));
        Intent intent = new Intent(Intent.ACTION_VIEW, addressUri);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "No application can handle this request", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareText() {
        String text = shareTextEditText.getText().toString();
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, text);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(Intent.createChooser(intent, "Share via"));
        } else {
            Toast.makeText(this, "No application can handle this request", Toast.LENGTH_SHORT).show();
        }
    }
}